package com.moosegames.subhunter;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.Display;
import android.util.Log;
import android.widget.ImageView;
import java.util.Random;

public class SubHunter extends Activity {

    // Local variables

    ImageView gameView;
    Bitmap blankBitmap;
    Canvas canvas;
    Paint paint;
    int numHorizontalPixels;
    int numVerticalPixels;
    int blockSize;
    int gridWidth = 40;
    int gridHeight;
    float playerTouchHorizontal = -100;
    float playerTouchVertical = -100;
    int subPosHorizontal;
    int subPosVertical;
    boolean hit = false;
    int numShotsTaken;
    int distanceFromSub;
    boolean debugging = true;

    /*
        Android runs this code just before
        the player sees the app.
        This makes it a good place to add code
        for the one-time setup phase
     */

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        // Get screen resolution

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);

        // Initialize screen size variables

        numHorizontalPixels = size.x;
        numVerticalPixels = size.y;
        blockSize = numHorizontalPixels / gridWidth;
        gridHeight = numVerticalPixels / blockSize;

        // Set up drawing variables

        blankBitmap = Bitmap.createBitmap(numHorizontalPixels,
                                          numVerticalPixels,
                                          Bitmap.Config.ARGB_8888);

        canvas = new Canvas(blankBitmap);
        gameView = new ImageView(this);
        paint = new Paint();

        setContentView(gameView);

        Log.d("Debugging","In onCreate");
        startGame();
        draw();
    }

      // Game Start
      void startGame()
      {
        Random RNG = new Random();
        subPosHorizontal = RNG.nextInt(gridWidth);
        subPosVertical = RNG.nextInt(gridHeight);
        numShotsTaken = 0;

        Log.d("Debugging", "In startGame");
      }

      // Draws grid lines, HUD, and touch indicator

      void draw()
      {
          gameView.setImageBitmap(blankBitmap);

          canvas.drawColor(Color.argb(255,255,255,255));
          paint.setColor(Color.argb(255,0,0,0));

          // drawLine(startX, startY, stopX, stopY, Paint() paint)

          // Note: Canvas is acting kind of weird. Some vertical lines might be missing

          for(int i = 0; i < gridWidth; i++)
          {

              canvas.drawLine(0, blockSize * i, numHorizontalPixels - 1,
                      blockSize * i, paint);
              canvas.drawLine(blockSize * i, 0, blockSize * i,
                      numVerticalPixels - 1, paint);

          }

          canvas.drawRect(playerTouchHorizontal * blockSize,
                          playerTouchVertical * blockSize,
                         (playerTouchHorizontal * blockSize) + blockSize,
                       (playerTouchVertical * blockSize) + blockSize,
                                paint);

          paint.setTextSize(blockSize * 2);
          paint.setColor(Color.argb(255,0,0,255));
          canvas.drawText("Shots Taken: " + numShotsTaken
                        + " Distance: " + distanceFromSub,
                           blockSize, blockSize * 1.75f, paint);

          Log.d("Debugging", "In draw");
          if(debugging) { printDebug(); }

      }

      // Detects player has touched screen

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
      Log.d("Debugging","In onTouchEvent");
      if( (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP )
      { takeShot(event.getX(), event.getY()); }

      return true;
    }


    // Executes when player taps screen

    void takeShot(float touchX, float touchY)
    {
        Log.d("Debugging", "In takeShot");

        numShotsTaken++;
        playerTouchHorizontal = (int)(touchX / blockSize);
        playerTouchVertical = (int)(touchY / blockSize);

        hit = (playerTouchHorizontal == subPosHorizontal)
                && (playerTouchVertical == subPosVertical);

        int horizontalGap = (int)(playerTouchHorizontal - subPosHorizontal);
        int verticalGap = (int)(playerTouchVertical - subPosVertical);

        distanceFromSub = (int)Math.sqrt( horizontalGap * horizontalGap
                                        + verticalGap * verticalGap );

        if(hit) { boom(); }
        else { draw(); }

    }
      // Calculates distance from sub and decides if its a hit

      // Outputs "BOOM!" when hit

    void boom()
    {
      gameView.setImageBitmap(blankBitmap);

      canvas.drawColor(Color.argb(255,255,0,0));

      paint.setColor(Color.argb(255,255,255,255));
      paint.setTextSize(blockSize * 10);
      canvas.drawText("BOOM!", blockSize * 4, blockSize * 14, paint);

      paint.setTextSize(blockSize * 2);
      canvas.drawText("Take a shot to start again", blockSize * 8,
                        blockSize * 18, paint);

      startGame();

    }

      // Debugging text

    void printDebug()
    {

        paint.setTextSize(blockSize);

        canvas.drawText("numHorizontalPixels = "  + numHorizontalPixels,
                         50, blockSize * 3, paint);
        canvas.drawText("numVerticalPixels = "  + numVerticalPixels,
                         50, blockSize * 4, paint);
        canvas.drawText("blockSize = "  + blockSize,
                         50, blockSize * 5, paint);
        canvas.drawText("gridWidth = "  + gridHeight,
                         50, blockSize * 6, paint);
        canvas.drawText("gridHeight = "  + gridHeight,
                         50, blockSize * 7, paint);
        canvas.drawText("playerTouchHorizontal = "  + playerTouchHorizontal,
                         50, blockSize * 8, paint);
        canvas.drawText("playerTouchVertical = "  + playerTouchVertical,
                         50, blockSize * 9, paint);
        canvas.drawText("subPosHorizontal = "  + subPosHorizontal,
                         50, blockSize * 10, paint);
        canvas.drawText("subPosVertical = "  + subPosVertical,
                         50, blockSize * 11, paint);
        canvas.drawText("hit = "  + hit,
                         50, blockSize * 12, paint);
        canvas.drawText("numShotsTaken = "  + numShotsTaken,
                         50, blockSize * 13, paint);
        canvas.drawText("debugging = "  + debugging,
                         50, blockSize * 14, paint);

    }
}
